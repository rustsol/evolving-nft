import React, { useState, useEffect } from 'react';
import { useContract } from './hooks/useContract';
import { NFTViewer } from './components/NFTViewer';
import { MonanomalyNFT } from './types';
import './App.css';

function App() {
  const {
    contract,
    account,
    isConnected,
    isLoading,
    error,
    network,
    isCorrectNetwork,
    connectWallet,
    mintNFT,
    feedCreature,
    petCreature,
    trainCreature,
    angerCreature,
    transferNFT,
    getUserNFTs
  } = useContract();

  const [userNFTs, setUserNFTs] = useState<MonanomalyNFT[]>([]);
  const [selectedNFT, setSelectedNFT] = useState<MonanomalyNFT | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  // Fetch user NFTs when connected
  useEffect(() => {
    if (isConnected && contract) {
      refreshNFTs();
    }
  }, [isConnected, contract]);

  const refreshNFTs = async () => {
    try {
      setRefreshing(true);
      const nfts = await getUserNFTs();
      setUserNFTs(nfts);
      
      // Update selected NFT if it exists
      if (selectedNFT) {
        const updatedNFT = nfts.find(nft => nft.tokenId === selectedNFT.tokenId);
        if (updatedNFT) {
          setSelectedNFT(updatedNFT);
        }
      }
    } catch (error) {
      console.error('Error refreshing NFTs:', error);
    } finally {
      setRefreshing(false);
    }
  };

  const handleMint = async () => {
    try {
      await mintNFT();
      // Wait a moment for blockchain confirmation
      setTimeout(refreshNFTs, 2000);
    } catch (error) {
      console.error('Mint error:', error);
    }
  };

  const handleCreatureAction = async (action: 'feed' | 'pet' | 'train' | 'anger', tokenId: number) => {
    try {
      switch (action) {
        case 'feed':
          await feedCreature(tokenId);
          break;
        case 'pet':
          await petCreature(tokenId);
          break;
        case 'train':
          await trainCreature(tokenId);
          break;
        case 'anger':
          await angerCreature(tokenId);
          break;
      }
      // Refresh data after action
      setTimeout(refreshNFTs, 1000);
    } catch (error) {
      console.error(`${action} error:`, error);
    }
  };

  const handleTransfer = async (tokenId: number, toAddress: string) => {
    try {
      await transferNFT(tokenId, toAddress);
      // Refresh data after transfer
      setTimeout(refreshNFTs, 1000);
    } catch (error) {
      console.error('Transfer error:', error);
    }
  };

  return (
    <div className="App">
      {/* Header */}
      <header className="app-header">
        <div className="header-content">
          <h1 className="title">
            🔮 Monanomaly
            <span className="subtitle">Evolving Onchain Creatures</span>
          </h1>
          
          {!isConnected ? (
            <button 
              className="connect-btn" 
              onClick={connectWallet}
              disabled={isLoading}
            >
              {isLoading ? 'Connecting...' : 'Connect Wallet'}
            </button>
          ) : (
            <div className="wallet-info">
              <div className="network-indicator">
                <span className={`network-status ${isCorrectNetwork ? 'correct' : 'wrong'}`}>
                  {isCorrectNetwork ? '🟢' : '🔴'} {network || 'Unknown'}
                </span>
              </div>
              <span className="wallet-address">
                {account?.slice(0, 6)}...{account?.slice(-4)}
              </span>
              <button 
                className="refresh-btn" 
                onClick={refreshNFTs}
                disabled={refreshing}
              >
                {refreshing ? '🔄' : '↻'}
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="main-content">
        {error && (
          <div className="error-message">
            ⚠️ {error}
          </div>
        )}

        {isConnected && !isCorrectNetwork && (
          <div className="network-warning">
            🔄 You're on {network}. Switch to Monad Testnet for full functionality.
          </div>
        )}

        {!isConnected ? (
          <div className="welcome-section">
            <div className="welcome-card">
              <h2>Welcome to the Monad Realms!</h2>
              <p>
                Discover and evolve your own Monanomaly - a unique onchain creature 
                that grows and changes based on your interactions.
              </p>
              <div className="features">
                <div className="feature">
                  <span className="feature-icon">🍎</span>
                  <span>Feed to grow bigger</span>
                </div>
                <div className="feature">
                  <span className="feature-icon">❤️</span>
                  <span>Pet for happiness</span>
                </div>
                <div className="feature">
                  <span className="feature-icon">⚡</span>
                  <span>Train for power</span>
                </div>
                <div className="feature">
                  <span className="feature-icon">👹</span>
                  <span>Anger for spikes</span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="dashboard">
            {/* NFT Collection */}
            <div className="collection-section">
              <div className="section-header">
                <h2>Your Monanomalies ({userNFTs.length})</h2>
                <button 
                  className="mint-btn" 
                  onClick={handleMint}
                  disabled={isLoading}
                >
                  {isLoading ? 'Minting...' : '✨ Mint New Creature'}
                </button>
              </div>

              {userNFTs.length === 0 ? (
                <div className="empty-collection">
                  <p>You don't have any Monanomalies yet!</p>
                  <p>Mint your first creature to begin your journey.</p>
                </div>
              ) : (
                <div className="nft-grid">
                  {userNFTs.map((nft: MonanomalyNFT) => {
                    return (
                      <div 
                        key={nft.tokenId}
                        className={`nft-card-preview ${selectedNFT?.tokenId === nft.tokenId ? 'selected' : ''}`}
                        onClick={() => setSelectedNFT(nft)}
                      >
                        <div className="nft-preview-image">
                        <div
    className="svg-thumbnail"
    style={{ width: '100%', height: '100%' }}
    dangerouslySetInnerHTML={{
      __html: nft.metadata.image ? atob(nft.metadata.image.split(',')[1]) : ''
    }}
  />
                        </div>
                        <div className="nft-preview-info">
                          <h4>{nft.metadata.name}</h4>
                          <p>Happiness: {nft.traits.happiness}/10</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Selected NFT Details */}
            {selectedNFT && (
              <div className="details-section">
                <NFTViewer
                  nft={selectedNFT}
                  onFeed={(tokenId) => handleCreatureAction('feed', tokenId)}
                  onPet={(tokenId) => handleCreatureAction('pet', tokenId)}
                  onTrain={(tokenId) => handleCreatureAction('train', tokenId)}
                  onAnger={(tokenId) => handleCreatureAction('anger', tokenId)}
                  onTransfer={handleTransfer}
                  isLoading={isLoading}
                />
              </div>
            )}
          </div>
        )}
      </main>

      {/* Floating Background Elements */}
      <div className="background-elements">
        <div className="floating-orb orb-1" />
        <div className="floating-orb orb-2" />
        <div className="floating-orb orb-3" />
      </div>
    </div>
  );
}

export default App;