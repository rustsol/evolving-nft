import React, { useState, useEffect } from 'react';

interface NetworkCheckerProps {
  children: React.ReactNode;
}

const MONAD_TESTNET = {
  chainId: '0x279F', // 10143 in hex
  chainName: 'Monad Testnet',
  rpcUrls: ['https://testnet-rpc.monad.xyz'],
  nativeCurrency: {
    name: 'MON',
    symbol: 'MON',
    decimals: 18,
  },
  blockExplorerUrls: ['https://testnet.monadexplorer.com'],
};

export const NetworkChecker: React.FC<NetworkCheckerProps> = ({ children }) => {
  const [isCorrectNetwork, setIsCorrectNetwork] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const checkNetwork = async () => {
    try {
      if (!window.ethereum) {
        setIsLoading(false);
        return;
      }

      const chainId = await window.ethereum.request({ method: 'eth_chainId' });
      setIsCorrectNetwork(chainId === MONAD_TESTNET.chainId);
    } catch (error) {
      console.error('Error checking network:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const switchToMonadTestnet = async () => {
    try {
      setIsLoading(true);
      
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: MONAD_TESTNET.chainId }],
      });
    } catch (switchError: any) {
      if (switchError.code === 4902) {
        try {
          await window.ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [MONAD_TESTNET],
          });
        } catch (addError) {
          console.error('Failed to add Monad Testnet:', addError);
        }
      } else {
        console.error('Failed to switch network:', switchError);
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkNetwork();

    if (window.ethereum) {
      window.ethereum.on('chainChanged', checkNetwork);
      return () => {
        window.ethereum.removeListener('chainChanged', checkNetwork);
      };
    }
  }, []);

  if (isLoading) {
    return (
      <div className="network-loading">
        <div className="loading-spinner">🔄</div>
        <p>Checking network...</p>
      </div>
    );
  }

  if (!window.ethereum) {
    return (
      <div className="network-error">
        <h3>MetaMask Required</h3>
        <p>Please install MetaMask to use this application.</p>
        <a 
          href="https://metamask.io/download/" 
          target="_blank" 
          rel="noopener noreferrer"
          className="install-metamask-btn"
        >
          Install MetaMask
        </a>
      </div>
    );
  }

  if (!isCorrectNetwork) {
    return (
      <div className="network-error">
        <h3>Wrong Network</h3>
        <p>Please connect to Monad Testnet to use this application.</p>
        <button onClick={switchToMonadTestnet} className="switch-network-btn">
          Switch to Monad Testnet
        </button>
        <div className="network-details">
          <h4>Network Details:</h4>
          <ul>
            <li><strong>Name:</strong> Monad Testnet</li>
            <li><strong>RPC URL:</strong> {MONAD_TESTNET.rpcUrls[0]}</li>
            <li><strong>Chain ID:</strong> 10143</li>
            <li><strong>Currency:</strong> MON</li>
          </ul>
        </div>
        
        <style>{`
          .network-error {
            max-width: 500px;
            margin: 2rem auto;
            padding: 2rem;
            background: linear-gradient(135deg, #FF6B6B, #FF4444);
            border-radius: 20px;
            text-align: center;
            color: white;
            box-shadow: 0 10px 30px rgba(255, 107, 107, 0.3);
          }
          
          .network-error h3 {
            margin: 0 0 1rem 0;
            font-size: 1.5rem;
          }
          
          .network-error p {
            margin: 0 0 1.5rem 0;
            opacity: 0.9;
          }
          
          .switch-network-btn, .install-metamask-btn {
            background: rgba(255, 255, 255, 0.2);
            border: 2px solid rgba(255, 255, 255, 0.5);
            color: white;
            padding: 12px 24px;
            border-radius: 15px;
            cursor: pointer;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
          }
          
          .switch-network-btn:hover, .install-metamask-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            border-color: white;
            transform: translateY(-2px);
          }
          
          .network-details {
            margin-top: 2rem;
            padding: 1rem;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 10px;
          }
          
          .network-details h4 {
            margin: 0 0 1rem 0;
            color: #FFD700;
          }
          
          .network-details ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: left;
          }
          
          .network-details li {
            margin: 0.5rem 0;
            font-size: 0.9rem;
          }
          
          .network-loading {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 200px;
            color: white;
          }
          
          .loading-spinner {
            font-size: 2rem;
            animation: spin 1s linear infinite;
          }
          
          @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    );
  }

  return <>{children}</>;
};