import React, { useState, useEffect } from 'react';
import { MonanomalyNFT } from '../types';
import { LoadingSpinner } from './LoadingSpinner';
import {
  getEvolutionLevel,
  getPersonality,
  getMood,
  getEnergyLevel,
  getWingStage,
  getNextEvolutionRequirements,
  getTraitColor,
  generateEvolutionStory,
  copyToClipboard
} from '../utils/helpers';

interface EnhancedNFTViewerProps {
  nft: MonanomalyNFT;
  onFeed: (tokenId: number) => Promise<void>;
  onPet: (tokenId: number) => Promise<void>;
  onTrain: (tokenId: number) => Promise<void>;
  onAnger: (tokenId: number) => Promise<void>;
  isLoading: boolean;
}

export const EnhancedNFTViewer: React.FC<EnhancedNFTViewerProps> = ({
  nft,
  onFeed,
  onPet,
  onTrain,
  onAnger,
  isLoading
}) => {
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [svgData, setSvgData] = useState<string>('');
  const [showStory, setShowStory] = useState(false);
  const [copiedMessage, setCopiedMessage] = useState<string | null>(null);

  useEffect(() => {
    // Extract and decode SVG from metadata
    if (nft.metadata.image) {
      const base64Data = nft.metadata.image.split(',')[1];
      const svgString = atob(base64Data);
      setSvgData(svgString);
    }
  }, [nft.metadata.image]);

  const handleAction = async (action: string, actionFn: () => Promise<void>) => {
    try {
      setActionLoading(action);
      await actionFn();
    } catch (error) {
      console.error(`Error ${action}:`, error);
    } finally {
      setActionLoading(null);
    }
  };

  const handleCopyTokenURI = async () => {
    const tokenURI = `data:application/json;base64,${btoa(JSON.stringify(nft.metadata))}`;
    const success = await copyToClipboard(tokenURI);
    if (success) {
      setCopiedMessage('Token URI copied!');
      setTimeout(() => setCopiedMessage(null), 2000);
    }
  };

  const evolution = getEvolutionLevel(nft.traits);
  const personality = getPersonality(nft.traits);
  const mood = getMood(nft.traits.happiness);
  const energy = getEnergyLevel(nft.traits.eyeGlow);
  const wingStage = getWingStage(nft.traits.wings);
  const nextRequirements = getNextEvolutionRequirements(nft.traits);
  const story = generateEvolutionStory(nft.traits);

  return (
    <div className="enhanced-nft-viewer">
      <div className="nft-card">
        {/* Header with enhanced info */}
        <div className="nft-header">
          <div className="title-section">
            <h3 className="nft-title">{nft.metadata.name}</h3>
            <p className="creature-personality">{personality}</p>
          </div>
          <div className="badges">
            <span 
              className="evolution-badge"
              style={{ backgroundColor: evolution.color, color: evolution.color === '#FFFFFF' ? '#000' : '#FFF' }}
            >
              {evolution.level}
            </span>
            <span className="mood-badge">
              {mood.emoji} {mood.mood}
            </span>
          </div>
        </div>

        {/* Enhanced SVG Display */}
        <div className="nft-image-container">
          <div className="nft-image">
            <div 
              dangerouslySetInnerHTML={{ __html: svgData }}
              className="svg-container"
            />
          </div>
          <div className="image-overlay">
            <div className="creature-stats-overlay">
              <div className="stat-pill">⚡ {energy.level}</div>
              <div className="stat-pill">🪶 {wingStage}</div>
              <div className="stat-pill">Tier {evolution.tier}</div>
            </div>
          </div>
          <div className="floating-elements">
            <div className="particle particle-1" />
            <div className="particle particle-2" />
            <div className="particle particle-3" />
            <div className="particle particle-4" />
          </div>
        </div>

        {/* Story Section */}
        <div className="story-section">
          <button 
            className="story-toggle"
            onClick={() => setShowStory(!showStory)}
          >
            📖 {showStory ? 'Hide' : 'Show'} Creature Story
          </button>
          {showStory && (
            <div className="story-content">
              <p className="story-text">{story}</p>
            </div>
          )}
        </div>

        {/* Enhanced Traits Section */}
        <div className="traits-section">
          <h4>Creature Attributes</h4>
          <div className="traits-grid">
            {[
              { label: 'Body Size', value: nft.traits.bodySize, max: 10, icon: '🫧' },
              { label: 'Happiness', value: nft.traits.happiness, max: 10, icon: '😊' },
              { label: 'Energy', value: nft.traits.eyeGlow, max: 10, icon: '⚡' },
              { label: 'Aura Power', value: nft.traits.aura, max: 5, icon: '✨' },
              { label: 'Wing Level', value: nft.traits.wings, max: 3, icon: '🪶' },
              { label: 'Spike Count', value: nft.traits.spikes, max: 5, icon: '🔥' },
            ].map((trait, index) => (
              <div key={index} className="trait-item">
                <div className="trait-header">
                  <span className="trait-icon">{trait.icon}</span>
                  <span className="trait-label">{trait.label}:</span>
                </div>
                <div className="trait-bar-container">
                  <div className="trait-bar">
                    <div 
                      className="trait-fill" 
                      style={{ 
                        width: `${(trait.value / trait.max) * 100}%`,
                        backgroundColor: getTraitColor(trait.value, trait.max)
                      }}
                    />
                  </div>
                  <span className="trait-value">{trait.value}/{trait.max}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Next Evolution Requirements */}
        {nextRequirements.length > 0 && (
          <div className="requirements-section">
            <h4>🎯 Evolution Goals</h4>
            <div className="requirements-list">
              {nextRequirements.map((req, index) => (
                <div key={index} className="requirement-item">
                  <span className="requirement-text">{req.description}</span>
                  <div className="requirement-progress">
                    <div className="progress-bar">
                      <div 
                        className="progress-fill"
                        style={{ width: `${(req.current / req.max) * 100}%` }}
                      />
                    </div>
                    <span className="progress-text">{req.current}/{req.max}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Enhanced Action Buttons */}
        <div className="actions-section">
          <h4>⚗️ Evolution Actions</h4>
          <div className="action-buttons">
            {[
              { 
                action: 'feed', 
                label: 'Feed', 
                icon: '🍎', 
                description: '+Size, +Happy',
                color: '#4CAF50',
                fn: onFeed
              },
              { 
                action: 'pet', 
                label: 'Pet', 
                icon: '❤️', 
                description: '+Happy, +Aura',
                color: '#FF69B4',
                fn: onPet
              },
              { 
                action: 'train', 
                label: 'Train', 
                icon: '⚡', 
                description: '+Energy, +Wings',
                color: '#FFD700',
                fn: onTrain
              },
              { 
                action: 'anger', 
                label: 'Anger', 
                icon: '😠', 
                description: '+Spikes, +Energy',
                color: '#FF6B6B',
                fn: onAnger
              }
            ].map((btn) => (
              <button
                key={btn.action}
                className="action-btn"
                style={{ '--btn-color': btn.color } as React.CSSProperties}
                onClick={() => handleAction(btn.action, () => btn.fn(nft.tokenId))}
                disabled={isLoading || actionLoading === btn.action}
              >
                <div className="btn-content">
                  <span className="btn-icon">{btn.icon}</span>
                  <span className="btn-label">{btn.label}</span>
                  <span className="btn-description">{btn.description}</span>
                </div>
                {actionLoading === btn.action && (
                  <LoadingSpinner size="small" message="" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Enhanced Stats Section */}
        <div className="stats-section">
          <h4>📊 Interaction History</h4>
          <div className="stats-grid">
            {[
              { label: 'Times Fed', value: nft.stats.timesFed, icon: '🍎' },
              { label: 'Times Petted', value: nft.stats.timesPetted, icon: '❤️' },
              { label: 'Times Trained', value: nft.stats.timesTrained, icon: '⚡' },
              { label: 'Transfers', value: nft.stats.timesTransferred, icon: '↔️' },
            ].map((stat, index) => (
              <div key={index} className="stat-item">
                <span className="stat-icon">{stat.icon}</span>
                <span className="stat-label">{stat.label}:</span>
                <span className="stat-value">{stat.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Utility Actions */}
        <div className="utility-section">
          <button className="utility-btn" onClick={handleCopyTokenURI}>
            📋 Copy Metadata
          </button>
          {copiedMessage && (
            <span className="copied-message">{copiedMessage}</span>
          )}
        </div>
      </div>

      <style>{`
        .enhanced-nft-viewer {
          max-width: 600px;
          margin: 0 auto;
        }

        .nft-card {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          border-radius: 20px;
          padding: 25px;
          box-shadow: 0 25px 50px rgba(0,0,0,0.15);
          color: white;
          position: relative;
          overflow: hidden;
          border: 1px solid rgba(255,255,255,0.1);
        }

        .nft-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 25px;
        }

        .title-section {
          flex: 1;
        }

        .nft-title {
          margin: 0 0 5px 0;
          font-size: 1.6rem;
          font-weight: bold;
        }

        .creature-personality {
          margin: 0;
          font-size: 0.9rem;
          opacity: 0.8;
          color: #FFD700;
          font-style: italic;
        }

        .badges {
          display: flex;
          flex-direction: column;
          gap: 8px;
          align-items: flex-end;
        }

        .evolution-badge, .mood-badge {
          padding: 6px 12px;
          border-radius: 15px;
          font-size: 0.75rem;
          font-weight: bold;
          text-transform: uppercase;
        }

        .mood-badge {
          background: rgba(255,255,255,0.2);
          border: 1px solid rgba(255,255,255,0.3);
        }

        .nft-image-container {
          position: relative;
          background: linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05));
          border-radius: 20px;
          padding: 25px;
          margin-bottom: 25px;
          overflow: hidden;
          border: 1px solid rgba(255,255,255,0.1);
        }

        .nft-image {
          width: 100%;
          height: 350px;
          display: flex;
          justify-content: center;
          align-items: center;
          position: relative;
        }

        .svg-container {
          width: 100%;
          height: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
        }

        .svg-container svg {
          max-width: 100%;
          max-height: 100%;
          filter: drop-shadow(0 10px 20px rgba(0,0,0,0.3));
        }

        .image-overlay {
          position: absolute;
          top: 15px;
          right: 15px;
        }

        .creature-stats-overlay {
          display: flex;
          flex-direction: column;
          gap: 5px;
        }

        .stat-pill {
          background: rgba(0,0,0,0.7);
          color: white;
          padding: 4px 8px;
          border-radius: 12px;
          font-size: 0.7rem;
          font-weight: bold;
          backdrop-filter: blur(10px);
        }

        .floating-elements {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
        }

        .particle {
          position: absolute;
          width: 3px;
          height: 3px;
          background: #FFD700;
          border-radius: 50%;
          opacity: 0.8;
          animation: float 4s ease-in-out infinite;
        }

        .particle-1 { top: 15%; left: 15%; animation-delay: 0s; }
        .particle-2 { top: 70%; right: 20%; animation-delay: 1s; background: #00FF88; }
        .particle-3 { bottom: 40%; left: 25%; animation-delay: 2s; background: #00D4FF; }
        .particle-4 { top: 40%; right: 15%; animation-delay: 3s; background: #FF69B4; }

        @keyframes float {
          0%, 100% { transform: translateY(0px) scale(1); opacity: 0.8; }
          50% { transform: translateY(-15px) scale(1.2); opacity: 1; }
        }

        .story-section {
          margin-bottom: 25px;
        }

        .story-toggle {
          background: rgba(255,255,255,0.1);
          border: 1px solid rgba(255,255,255,0.2);
          color: white;
          padding: 8px 16px;
          border-radius: 20px;
          cursor: pointer;
          font-size: 0.9rem;
          transition: all 0.3s ease;
          width: 100%;
        }

        .story-toggle:hover {
          background: rgba(255,255,255,0.2);
        }

        .story-content {
          margin-top: 15px;
          padding: 15px;
          background: rgba(255,255,255,0.1);
          border-radius: 10px;
          border-left: 4px solid #FFD700;
        }

        .story-text {
          margin: 0;
          font-style: italic;
          line-height: 1.6;
          color: rgba(255,255,255,0.9);
        }

        .traits-section, .actions-section, .stats-section, .requirements-section {
          margin-bottom: 25px;
        }

        .traits-section h4, .actions-section h4, .stats-section h4, .requirements-section h4 {
          margin: 0 0 15px 0;
          color: #FFD700;
          font-size: 1.1rem;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .traits-grid {
          display: grid;
          gap: 12px;
        }

        .trait-item {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .trait-header {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .trait-icon {
          font-size: 1.1rem;
        }

        .trait-label {
          font-size: 0.9rem;
          font-weight: 500;
        }

        .trait-bar-container {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .trait-bar {
          flex: 1;
          height: 10px;
          background: rgba(255,255,255,0.2);
          border-radius: 5px;
          overflow: hidden;
        }

        .trait-fill {
          height: 100%;
          transition: width 0.5s ease, background-color 0.3s ease;
          border-radius: 5px;
        }

        .trait-value {
          min-width: 40px;
          text-align: right;
          font-size: 0.85rem;
          font-weight: bold;
        }

        .requirements-list {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .requirement-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 10px;
          background: rgba(255,255,255,0.1);
          border-radius: 8px;
        }

        .requirement-text {
          font-size: 0.9rem;
          flex: 1;
        }

        .requirement-progress {
          display: flex;
          align-items: center;
          gap: 8px;
          min-width: 80px;
        }

        .progress-bar {
          width: 50px;
          height: 6px;
          background: rgba(255,255,255,0.2);
          border-radius: 3px;
          overflow: hidden;
        }

        .progress-fill {
          height: 100%;
          background: #00FF88;
          transition: width 0.3s ease;
        }

        .progress-text {
          font-size: 0.8rem;
          font-weight: bold;
          min-width: 30px;
        }

        .action-buttons {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
        }

        .action-btn {
          padding: 15px 10px;
          border: none;
          border-radius: 12px;
          cursor: pointer;
          transition: all 0.3s ease;
          background: var(--btn-color);
          color: white;
          position: relative;
          overflow: hidden;
        }

        .action-btn:hover:not(:disabled) {
          transform: translateY(-3px);
          box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        }

        .action-btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .btn-content {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
        }

        .btn-icon {
          font-size: 1.2rem;
        }

        .btn-label {
          font-weight: bold;
          font-size: 0.9rem;
        }

        .btn-description {
          font-size: 0.7rem;
          opacity: 0.9;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
        }

        .stat-item {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 10px 12px;
          background: rgba(255,255,255,0.1);
          border-radius: 10px;
          border: 1px solid rgba(255,255,255,0.1);
        }

        .stat-icon {
          font-size: 1rem;
        }

        .stat-label {
          font-size: 0.85rem;
          flex: 1;
        }

        .stat-value {
          font-weight: bold;
          color: #FFD700;
          font-size: 0.9rem;
        }

        .utility-section {
          display: flex;
          align-items: center;
          gap: 10px;
          padding-top: 15px;
          border-top: 1px solid rgba(255,255,255,0.1);
        }

        .utility-btn {
          background: rgba(255,255,255,0.1);
          border: 1px solid rgba(255,255,255,0.2);
          color: white;
          padding: 8px 16px;
          border-radius: 15px;
          cursor: pointer;
          font-size: 0.8rem;
          transition: all 0.3s ease;
        }

        .utility-btn:hover {
          background: rgba(255,255,255,0.2);
        }

        .copied-message {
          font-size: 0.8rem;
          color: #00FF88;
          font-weight: bold;
        }

        @media (max-width: 768px) {
          .nft-header {
            flex-direction: column;
            gap: 15px;
          }

          .badges {
            align-items: flex-start;
            flex-direction: row;
          }

          .action-buttons {
            grid-template-columns: 1fr;
          }

          .stats-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
};